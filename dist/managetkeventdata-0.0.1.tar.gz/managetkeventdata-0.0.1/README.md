# Makes _something_ easy again!
[![License: MIT](https://img.shields.io/github/license/Gribouillis/managetkeventdata)](https://opensource.org/licenses/MIT)
[![stars](https://img.shields.io/github/stars/Gribouillis/managetkeventdata)]()
[![Github All Releases](https://img.shields.io/github/downloads/Gribouillis/managetkeventdata/total.svg)]()
[![PyPI](https://img.shields.io/pypi/v/managetkeventdata)](https://pypi.org/project/managetkeventdata/)
[![python](https://img.shields.io/github/languages/top/Gribouillis/managetkeventdata)]()

[![Build Status](https://scrutinizer-ci.com/g/Gribouillis/managetkeventdata/badges/build.png?b=main)](https://scrutinizer-ci.com/g/Gribouillis/managetkeventdata/build-status/main)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/Gribouillis/managetkeventdata/badges/quality-score.png?b=main)](https://scrutinizer-ci.com/g/Gribouillis/managetkeventdata/?branch=main)
[![Release date](https://img.shields.io/github/release-date/Gribouillis/managetkeventdata)]()
[![Latest Stable Version](https://img.shields.io/github/v/release/Gribouillis/managetkeventdata)]()

[![tweet](https://img.shields.io/twitter/url?style=social&url=https%3A%2F%2Fgithub.com%2FGribouillis%2Fmanagetkeventdata)](https://twitter.com/intent/tweet?text=I%20found%20this%20awesome%20repo%20on%20GitHub%20%26%20PyPI%20that%20simplifies%20life%20of%20developers%20so%20much!&url=https%3A%2F%2Fgithub.com%2FGribouillis%2Fmanagetkeventdata)

### Support me


[![Buy Me A Coffee](https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png)](https://www.buymeacoffee.com/Gribouillis)


Some appreciatory description
- [x] Lightweight
- [x] Easiest to use 

## Install from PyPi
```
pip3 install managetkeventdata
```

## Or Install from main branch
```
pip3 install git+https://github.com/Gribouillis/managetkeventdata.git
```

# Example usage!
Use it like this..
```
cmpp
```

You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

